
# Cosmic Harvest: By OpaJones, Ozadius, & MichaelsLife

# Summary:

- The Cosmic Harvest datapack is an out-of-this-world experience that brings new plant life from other worlds, transported via cosmic cargo ships that crash land on Earth. Different seed types can be found at these crash sites, and planted on farmland to produce exotic plants that can be harvested for various edibles and weapons.

***

# Crash Sites:

- When a crash landing has been sighted, you will be notified through the chat window. You can use a compass to locate the crash site once you are notified of one nearby. Cosmic crashes happen only on land, away from large bodies of water.

- Each crash-landed ship contains a cargo block that holds special loot. Defeat the Everild pilot to obtain the key that unlocks the cargo.

# Custom Mob: The Everild

In the vast expanse of the cosmos, there exists a race known as the Everild, hostile beings whose tactics are rivaled only by their abysmal sense of direction. Every century or so, they embark on a perilous odyssey across the galaxy, bearing precious cargo of horticultural wonders to far-flung worlds. Yet, tragically, their journey often intersects with the gravitational embrace of our own Earth, rendering them vulnerable prey to both opportunistic plunderers and intrepid prospectors.

Despite their navigational woes, the Everild possess a formidable arsenal of survival senses. With a flicker of otherworldly energy, they can vanish and reappear in the blink of an eye, catching adversaries off-guard with their teleportation prowess. While their resilience is legendary, akin to that of an impervious fortress, alas, their physical might rivals that of the humble sloth.

# Custom Plants: Vantera, Florinus, & Nereus

- There are 3 new plants introduced that can be planted on farmland using seeds found at crash sites. These plants only grow in the dark, but can be grown quickly using lugos powder obtained from a crash site.

- Vantera: The vantera plant is a cycad-like stalk with sharp thorns that are poisonous to the touch. It produces Vantera Flesh when harvested, and has a rare chance of giving up one of its stalks to be used as a weapon that shoots thorns.
- Florinus: The florinus plant is an orchid-like flower with sharp leaves that it uses for defense. It produces a Florinus Leaf when harvested, and has a rare chance of giving up its star to be used as a weapon that can be thrown at enemies.
- Nereus: The nereus plant is a fungus-like sprout with poisonous bulbs that secrete a non-toxic and nutritious liquid. It produces nereus lac which can be harvested by using an empty bucket on the plant, and has a rare change of giving up one of its bulbs to be used as a weapon that creates a poisonous dust cloud that disturbs the enemy.

- To break a custom plant and get the seed item back, select a hoe item and press left-click on the plant.
- To harvest a custom plant when it's fully grown, right-click the plant. The plant must have a light level less than 9 in order to grow naturally, or you can use lugos powder on the plant to make it grow faster.

# Cheats:

- Type this command to get all available items for this datapack:
  /function om_harvest:player/item/all

- Type this command to summon an Everild:
  /function om_harvest:mob/everild

***

# Important Notes:

- To unload the datapack, run this function:
  /function om_harvest:system/unload
